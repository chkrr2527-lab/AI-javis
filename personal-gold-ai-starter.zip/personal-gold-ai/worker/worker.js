// Personal Gold AI - Cloudflare Worker starter
// Configure secrets: HOOK_PATH, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
// Do not put secrets in the website/Pine Script.
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type,Authorization",
    };
    if (request.method === "OPTIONS") return new Response(null, {headers:cors});
    const json = (data, status=200) => new Response(JSON.stringify(data), {
      status, headers: {...cors, "Content-Type":"application/json; charset=utf-8"}
    });
    if (url.pathname === "/api/health" && request.method === "GET") {
      return json({ok:true, app:"Personal Gold AI", version:"0.1.0", mode:"starter", marketData:"not-connected"});
    }
    // TradingView webhook endpoint. Keep HOOK_PATH long and random.
    if (request.method === "POST" && env.HOOK_PATH && url.pathname === `/hook/${env.HOOK_PATH}`) {
      let body;
      try { body = await request.json(); } catch { return json({ok:false,error:"invalid_json"},400); }
      const allowed = ["symbol","timeframe","time","close","open","high","low","ema50","ema200","rsi14","signal","source"];
      const safe = {};
      for (const key of allowed) if (body[key] !== undefined) safe[key] = String(body[key]).slice(0,120);
      if (!safe.symbol || !safe.time || !safe.close) return json({ok:false,error:"missing_required_fields"},400);
      if (env.TELEGRAM_BOT_TOKEN && env.TELEGRAM_CHAT_ID) {
        const lines = [
          "PERSONAL GOLD AI · MARKET UPDATE",
          `Symbol: ${safe.symbol}`,
          `TF: ${safe.timeframe || "-"}`,
          `Time: ${safe.time}`,
          `Close: ${safe.close}`,
          `Signal: ${safe.signal || "DATA ONLY"}`,
          `Source: ${safe.source || "TradingView"}`
        ];
        const tg = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method:"POST", headers:{"Content-Type":"application/json"},
          body:JSON.stringify({chat_id:env.TELEGRAM_CHAT_ID,text:lines.join("\n")})
        });
        if (!tg.ok) return json({ok:false,error:"telegram_send_failed"},502);
      }
      return json({ok:true,received:true,telegramConfigured:!!(env.TELEGRAM_BOT_TOKEN&&env.TELEGRAM_CHAT_ID)});
    }
    return json({ok:false,error:"not_found"},404);
  }
};
