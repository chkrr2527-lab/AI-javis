# Personal Gold AI — Starter 0.1.0

โครงงานเริ่มต้นสำหรับ OPPO A60 4G / Android โดยใช้มือถือเปิด PWA และให้บริการเว็บ/Cloud ทำงานแทนมือถือ

## สถานะจริงของรุ่นนี้
- มี Mobile-first dashboard
- มี TradingView chart widget โดยใช้สัญลักษณ์เริ่มต้น `TVC:XAUUSD`
- มีช่องข้อมูลประกอบและปุ่มคัดลอก Prompt สำหรับส่งภาพ/ข้อมูลให้ AI วิเคราะห์
- มี Cloudflare Worker starter สำหรับ health check และรับ webhook ที่มี secret path
- มี Pine Script v6 สำหรับเตรียมข้อมูล OHLC + EMA50/200 + RSI14
- **ยังไม่มี live OHLC feed เข้า AI, ยังไม่มี AI API call, ยังไม่มี Telegram Bot เชื่อมต่อ**
- TradingView Basic/free ไม่รองรับ Webhook alerts ตามข้อกำหนดแพ็กเกจปัจจุบัน จึงยังใช้ webhook flow ไม่ได้จนกว่าจะมีแพ็กเกจที่รองรับ
- ห้ามใช้ข้อมูลจากกราฟฝังเป็น data feed หรือ scraping TradingView

## ไฟล์
- `index.html`, `style.css`, `app.js`: PWA dashboard
- `manifest.webmanifest`, `sw.js`: ติดตั้งเป็นเว็บแอป
- `worker/worker.js`: Cloudflare Worker receiver starter
- `pine/personal_gold_ai_bridge.pine`: Pine Script v6 สำหรับขั้นต่อไป

## Deploy หน้าเว็บฟรีด้วย GitHub Pages
1. สร้าง GitHub repository ชื่อ `personal-gold-ai` เป็น Public
2. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดจาก ZIP นี้เข้า repository (อย่าอัปโหลด ZIP อย่างเดียว)
3. เข้า Settings → Pages
4. Source เลือก Deploy from a branch
5. Branch เลือก `main`, folder เลือก `/ (root)`, กด Save
6. รอ URL `https://ชื่อผู้ใช้.github.io/personal-gold-ai/`
7. เปิด URL ใน Chrome บน OPPO → เมนู ⋮ → Add to Home screen / Install app

## Deploy Cloudflare Worker (ยังไม่ต้องทำจนกว่าจะถึงขั้น Telegram)
1. Cloudflare Dashboard → Workers & Pages → Create → Worker
2. ตั้งชื่อ `personal-gold-ai-api`
3. เปิด Quick Edit แล้วแทนที่โค้ดด้วย `worker/worker.js`
4. Deploy
5. Settings → Variables and Secrets เพิ่ม:
   - `HOOK_PATH` เป็นสตริงสุ่มยาวอย่างน้อย 32 ตัวอักษร
   - `TELEGRAM_BOT_TOKEN` เป็น Secret
   - `TELEGRAM_CHAT_ID` เป็น Secret
6. ทดสอบ `https://ชื่อ-worker.workers.dev/api/health`
7. อย่าส่ง Token หรือ Secret ให้ผู้อื่น และอย่าใส่ไว้ใน GitHub

## หมายเหตุเรื่อง TradingView
TradingView webhook ต้องมีสิทธิ์ตามแพ็กเกจและเปิด 2FA ก่อนใช้งาน ดู:
https://www.tradingview.com/support/solutions/43000529348-how-to-configure-webhook-alerts/
อย่าใส่รหัสผ่าน, API key หรือ Telegram token ใน Pine Script หรือข้อความ alert

## ขั้นต่อไป
เมื่อหน้าเว็บออนไลน์แล้ว ค่อยเพิ่ม Telegram bot, Cloud receiver, การเก็บแท่งราคา, technical engine ที่คำนวณจาก OHLC จริง และ AI provider router (Gemini/OpenAI/Claude) โดยเก็บ API keys ใน Cloud secrets เท่านั้น
